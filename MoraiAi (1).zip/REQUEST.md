BOT : 6285147636135
OWNER : 6283175242555
QRIS : https://files.catbox.moe/8dwffu.jpg
CH : 120363383602297174@newsletter
GRUB WA : https://chat.whatsapp.com/DokONwpY1JSJy8ZB9oOH32

nama bot : WafzzXy BOT
nama own : wafzzxy